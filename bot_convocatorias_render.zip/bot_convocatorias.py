# Aquí iría todo el código del bot (versión para cron job en Render)
# Usar el código que ya está en el textdoc 'bot_convocatorias.py'